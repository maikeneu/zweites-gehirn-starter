# Kleines Update für dein zweites Gehirn

Maike hat deinen Starter-Vault noch verbessert. Das Einrichtungs-Interview geht jetzt tiefer und holt wirklich dein Wissen heraus, dein Assistent kennt klare Spielregeln zum Speichern und Sortieren, und es sind zwei Ordner dazugekommen (06 Archiv und 07 Anhänge).

## Der einfachste Weg
Mach das morgen einfach mit Maike zusammen. Es dauert zwei Minuten.

## Wenn du es selbst einspielen möchtest
In diesem Paket liegen die gleichen Ordnernamen wie in deinem Starter-Vault. Zieh die Dateien aus diesem Paket in deinen Starter-Vault und bestätige, wenn gefragt wird, ob gleichnamige Dateien ersetzt werden sollen. Deine eigenen Notizen bleiben unberührt.

## Noch einfacher
Du kannst stattdessen den kompletten Starter-Ordner über deinen Link neu laden. Solange du noch nichts Eigenes hineingeschrieben hast, ist das der bequemste Weg.
