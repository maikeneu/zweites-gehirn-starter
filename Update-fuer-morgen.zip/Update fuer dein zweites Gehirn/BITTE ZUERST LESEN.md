# Kleines Update für dein zweites Gehirn

Am bequemsten lädst du den kompletten Starter-Ordner über deinen Link neu, solange du noch nichts Eigenes hineingeschrieben hast. Alternativ zieh die Dateien aus diesem Paket in deinen Starter-Vault und bestätige das Ersetzen gleichnamiger Dateien. Deine eigenen Notizen bleiben unberührt.
