# Kleines Update für dein zweites Gehirn

Maike hat deinen Starter-Vault noch verbessert. Das Einrichtungs-Interview geht jetzt tiefer und holt wirklich dein Wissen heraus, und dein Assistent kennt jetzt klare Spielregeln, wie er speichert und sortiert.

## Der einfachste Weg
Mach das morgen einfach mit Maike zusammen. Es dauert zwei Minuten.

## Wenn du es selbst einspielen möchtest
In diesem Paket liegen die gleichen Ordnernamen wie in deinem Starter-Vault. Zieh die Dateien aus diesem Paket in deinen Starter-Vault und bestätige, wenn du gefragt wirst, ob die gleichnamigen Dateien ersetzt werden sollen.

Es werden nur diese Dateien aktualisiert:
- CLAUDE.md
- MEMORY.md
- START HIER.md
- 00 Kontext/Einrichtungs-Interview.md
- 00 Kontext/Einrichtung-Fortschritt.md

Deine eigenen Notizen bleiben unberührt.

## Noch einfacher
Du kannst stattdessen auch den kompletten Starter-Ordner über deinen alten Link neu laden. Solange du noch nichts Eigenes hineingeschrieben hast, ist das der bequemste Weg.
