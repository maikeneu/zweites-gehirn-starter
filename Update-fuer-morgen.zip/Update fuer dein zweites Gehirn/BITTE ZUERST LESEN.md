# Kleines Update für dein zweites Gehirn

Maike hat deinen Starter-Vault verbessert. Das Einrichtungs-Interview hat jetzt einen Reflexionsteil zu deinen Zielen und einen eigenen Block für deine Außenwirkung und deinen Content. Postings, Blogbeiträge und Texte für deine Website.

## Der einfachste Weg
Mach das morgen mit Maike zusammen. Zwei Minuten.

## Selbst einspielen
Zieh die Dateien aus diesem Paket in deinen Starter-Vault und bestätige das Ersetzen gleichnamiger Dateien. Deine eigenen Notizen bleiben unberührt.

## Noch einfacher
Lad den kompletten Starter-Ordner über deinen Link neu, solange du noch nichts Eigenes hineingeschrieben hast.
